// Gary Friel - S1619426

package org.me.gcu.ukearthquaketracker;

import android.os.Build;

import java.io.Serializable;
import java.util.Date;

import androidx.annotation.RequiresApi;

@RequiresApi(api = Build.VERSION_CODES.O)
public class Earthquake implements Serializable {
    String title = "";
    String description = "";
    String location = "";
    String link = "";
    Date pubDate = new Date();
    String category = "";
    float geoLat = 0;
    float geoLong = 0;
    float depth = 0;
    float magnitude = 0;

    // EMPTY CONSTRUCTOR
    public Earthquake() {

    }

    // PARAMETER CONSTRUCTOR
    public Earthquake(String title, String description, String location, String link, Date pubDate, String category, float geoLat, float geoLong, float depth, float magnitude) {
        this.title = title;
        this.description = description;
        this.location = location;
        this.link = link;
        this.pubDate = pubDate;
        this.category = category;
        this.geoLat = geoLat;
        this.geoLong = geoLong;
        this.depth = depth;
        this.magnitude = magnitude;
    }

    // GETTERS AND SETTERS
    public String getTitle() {
        return title;
    }

    public void setTitle(String newTitle) {
        this.title = newTitle;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String newDescription) {
        this.description = newDescription;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String newLocation) {
        this.location = newLocation;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String newLink) {
        this.link = newLink;
    }

    public Date getPubDate() {
        return pubDate;
    }

    public void setPubDate(Date newPubDate) {
        this.pubDate = newPubDate;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String newCategory) {
        this.category = newCategory;
    }

    public Float getGeoLat() {
        return geoLat;
    }

    public void setGeoLat(Float newGeoLat) {
        this.geoLat = newGeoLat;
    }

    public Float getGeoLong() {
        return geoLong;
    }

    public void setGeoLong(Float newGeoLong) {
        this.geoLat = newGeoLong;
    }

    public float getDepth() {
        return depth;
    }

    public void setDepth(float newDepth) {
        this.depth = newDepth;
    }

    public float getMagnitude() {
        return magnitude;
    }

    public void setMagnitude(float newMagnitude) {
        this.magnitude = newMagnitude;
    }
}
