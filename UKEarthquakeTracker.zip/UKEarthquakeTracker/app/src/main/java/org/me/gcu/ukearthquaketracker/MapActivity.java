// Gary Friel - S1619426

package org.me.gcu.ukearthquaketracker;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

public class MapActivity extends AppCompatActivity implements OnMapReadyCallback {

    // Global variables
    private GoogleMap mMap;
    private List<Earthquake> alist = new ArrayList<Earthquake>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        // Retrieve earthquake list from intent
        Intent intent = getIntent();
        alist = (List<Earthquake>)intent.getSerializableExtra("EarthquakeList");

        // Wait for message from map
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        super.onOptionsItemSelected(item);
        switch (item.getItemId())
        {
            case R.id.homePage:
                openHome();
                break;
            case R.id.mapPage:
                openMap();
                break;
        }
        return true;
    }

    // Passing through list of earthquake entries to home activity
    public void openHome() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("EarthquakeList", (Serializable) alist);
        startActivity(intent);
    }

    // Passing through list of earthquake entries to map activity
    public void openMap() {
        try {
            Intent intent = new Intent(this, MapActivity.class);
            if (alist.isEmpty()) {
                Toast.makeText(this, "Please load data first", Toast.LENGTH_LONG).show();
            }
            else {
                intent.putExtra("EarthquakeList", (Serializable) alist);
                startActivity(intent);
            }
        }
        catch (Exception e){
            Toast.makeText(this, "Please load data first", Toast.LENGTH_LONG).show();
        }
    }

    // When the map is loaded, the camera will be focused on the location and markers added
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onMapReady(GoogleMap googleMap)
    {
        // Initialize google map
        mMap = googleMap;

        // Make zoom tools available
        mMap.getUiSettings().setZoomControlsEnabled(true);

        // Initialize Lat/Long
        LatLng loc = new LatLng(0,0);

        // Cycle through the list of earthquakes and set markers based on latitude and longitude
        // Change marker colour based on strength of the earthquake
        for (Earthquake earth : alist) {
            loc = new LatLng(earth.geoLat, earth.geoLong);
            if (earth.magnitude >= 2) {
                mMap.addMarker(new MarkerOptions().position(loc).title("Loc: " + earth.location +
                        " Mag: " + earth.magnitude).icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_RED)));
            }
            else if (earth.magnitude >= 1.5 && earth.magnitude <= 1.9) {
                mMap.addMarker(new MarkerOptions().position(loc).title("Loc: " + earth.location +
                        " Mag: " + earth.magnitude).icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
            }
            else if (earth.magnitude >= 1 && earth.magnitude <= 1.4) {
                    mMap.addMarker(new MarkerOptions().position(loc).title("Loc: " + earth.location +
                            " Mag: " + earth.magnitude).icon(BitmapDescriptorFactory
                            .defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)));
            }
            else {
                mMap.addMarker(new MarkerOptions().position(loc).title("Loc: " + earth.location +
                        " Mag: " + earth.magnitude).icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
            }
        }

        // Move camera to the last entry in the earthquakes
        mMap.moveCamera(CameraUpdateFactory.newLatLng(loc));
    }
}