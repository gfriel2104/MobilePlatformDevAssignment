// Gary Friel - S1619426

package org.me.gcu.ukearthquaketracker;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.io.StringReader;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements OnClickListener {

    // Global variables
    private ListView listView ;
    private Button startButton;
    private Button searchButton;
    private String result = "";
    private EditText searchBox1;
    private EditText searchBox2;
    private TextView heading;
    private String resultProcessed = "";
    private String urlSource="http://quakes.bgs.ac.uk/feeds/MhSeismology.xml";
    private List<Earthquake> alist = new ArrayList<Earthquake>();
    final Calendar myCalendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Graphics Initialization
        listView = (ListView) findViewById(R.id.list);
        searchBox1 = (EditText) findViewById(R.id.searchBox1);
        searchBox1.setVisibility(View.GONE);
        searchBox2 = (EditText) findViewById(R.id.searchBox2);
        searchBox2.setVisibility(View.GONE);
        startButton = (Button)findViewById(R.id.startButton);
        searchButton = (Button)findViewById(R.id.searchButton);
        heading = (TextView)findViewById(R.id.heading);
        searchButton.setVisibility(View.GONE);
        heading.setVisibility(View.GONE);
        startButton.setOnClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    // When Data Retrieval Has Been Clicked
    public void onClick(View view)
    {
        startProgress();
    }

    public void startProgress()
    {
        // Run Network Access
        new Thread(new Task(urlSource)).start();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        super.onOptionsItemSelected(item);
        switch (item.getItemId())
        {
            case R.id.homePage:
                openHome();
                break;
            case R.id.mapPage:
                openMap();
                break;
        }

        return true;
    }

    // Passing through list of earthquake entries to home activity
    public void openHome() {
        try {
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("EarthquakeList", (Serializable) alist);
            startActivity(intent);
        }
        catch (Exception e){
            Toast.makeText(this, "Please load data first", Toast.LENGTH_LONG).show();
        }
    }

    // Passing through list of earthquake entries to map activity
    public void openMap() {
        try {
        Intent intent = new Intent(this, MapActivity.class);
        if (alist.isEmpty()) {
            Toast.makeText(this, "Please load data first", Toast.LENGTH_LONG).show();
        }
        else {
            intent.putExtra("EarthquakeList", (Serializable) alist);
            startActivity(intent);
        }
        }
        catch (Exception e){
            Toast.makeText(this, "Please load data first", Toast.LENGTH_LONG).show();
        }
    }

    // Update first date entry box
    private void updateLabel1() {
        String myFormat = "dd MMM yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.UK);
        searchBox1.setText(sdf.format(myCalendar.getTime()));
    }

    // Update second date entry box
    private void updateLabel2() {
        String myFormat = "dd MMM yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.UK);
        searchBox2.setText(sdf.format(myCalendar.getTime()));
    }

    // Thread for accessing data
    private class Task implements Runnable
    {
        private String url;
        public Task(String aurl)
        {
            url = aurl;
        }

        @RequiresApi(api = Build.VERSION_CODES.O)
        @Override
        public void run()
        {
            URL aurl;
            URLConnection yc;
            BufferedReader in = null;
            String inputLine = "";

            try
            {
                // Initialization for reader
                aurl = new URL(url);
                yc = aurl.openConnection();
                in = new BufferedReader(new InputStreamReader(yc.getInputStream()));

                while ((inputLine = in.readLine()) != null)
                {
                    result = result + inputLine;
                }

                // Removal of invalid characters
                resultProcessed = result.replace("geo:lat", "geolat");
                resultProcessed = resultProcessed.replace("geo:long", "geolong");

                // Removal of document introduction
                int index = resultProcessed.indexOf("<item>");
                resultProcessed = resultProcessed.substring(index);
                in.close();
            }
            catch (IOException ae)
            {
                Log.e("MyTag", "ioexception in run");
            }

            try
            {
                // Creation of Xml parsing resources
                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                factory.setNamespaceAware(true);
                XmlPullParser xpp = factory.newPullParser();
                xpp.setInput( new StringReader( resultProcessed ) );
                int eventType = xpp.getEventType();
                String tagName = "";
                Earthquake eq = new Earthquake();

                while (eventType != XmlPullParser.END_DOCUMENT)
                {
                    if(eventType == XmlPullParser.START_TAG)
                    {
                        tagName = xpp.getName();
                        // Check if this is a new earthquake
                        if (tagName.equals("item")) {
                            eq = new Earthquake();
                        }
                    }
                    else
                    if(eventType == XmlPullParser.TEXT)
                    {
                        String earthquakeDetails = xpp.getText();

                        // Check which tag was last received
                        // description contains data of depth, magnitude, location and lat/long
                        switch (tagName) {
                            case "title":
                                eq.title = earthquakeDetails;
                                break;
                            case "description":
                                eq.description = earthquakeDetails;
                                int depthIndex = earthquakeDetails.indexOf("Depth: ") + 7;
                                int depthEndIndex = earthquakeDetails.indexOf(" km");
                                int magnitudeIndex = earthquakeDetails.lastIndexOf("Magnitude: ") + 11;
                                int locIndexStart = earthquakeDetails.indexOf("Location: ") + 10;
                                int locIndexEnd = earthquakeDetails.indexOf("Lat/long") - 3;
                                eq.depth = Float.parseFloat(earthquakeDetails.substring(depthIndex, depthEndIndex));
                                eq.magnitude = Float.parseFloat(earthquakeDetails.substring(magnitudeIndex));
                                eq.location = earthquakeDetails.substring(locIndexStart, locIndexEnd);
                                break;
                            case "link":
                                eq.link = earthquakeDetails;
                                break;
                            case "pubDate":
                                Date dateInput= new Date();
                                DateFormat inputFormat = new SimpleDateFormat("EE, dd MMM yyyy HH:mm:ss");
                                try {
                                    dateInput = inputFormat.parse(earthquakeDetails);
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }
                                eq.pubDate = dateInput;
                                break;
                            case "category":
                                eq.category = earthquakeDetails;
                                break;
                            case "geolat":
                                eq.geoLat = Float.parseFloat(earthquakeDetails);
                                break;
                            case "geolong":
                                eq.geoLong = Float.parseFloat(earthquakeDetails);
                                alist.add(eq);
                                break;
                            default:
                                throw new IllegalStateException("Unexpected value: " + tagName);
                        }
                    }

                    eventType = xpp.next();

                }
            }
            catch (XmlPullParserException ae1)
            {
                Log.e("MyTag","Parsing error" + ae1.toString());
            }
            catch (IOException ae1)
            {
                Log.e("MyTag","IO error during parsing");
            }

            System.out.println("End document");

            // Running the button command
            MainActivity.this.runOnUiThread(new Runnable() {
                public void run() {

                    List<String> names = new ArrayList<String>();

                    // Create a string list of information to be passed to the linked list adapter
                    for (Earthquake earth : alist) {
                            names.add(earth.title + " \n\nMagnitude: " + earth.magnitude + " \nLocation: " + earth.location);
                        }

                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, android.R.id.text1, names) {
                        public View getView(int position, View convertView, ViewGroup parent) {

                            // Separation of location and magnitude details
                            int indexStart = getItem(position).lastIndexOf("Magnitude: ") + 11;
                            int indexEnd = getItem(position).lastIndexOf("Location: ") -1;
                            Float magnitude = Float.parseFloat(getItem(position).substring(indexStart, indexEnd));

                            View itemView = super.getView(position, convertView, parent);

                            // Change colour based on the earthquake's magnitude
                            if (magnitude >= 2)
                                itemView.setBackgroundColor(Color.RED);
                            else if (magnitude >= 1.5 && magnitude <= 1.9 ) {
                                itemView.setBackgroundColor(Color.rgb(255,140,0));
                            }
                            else if (magnitude >= 1 && magnitude <= 1.4) {
                                itemView.setBackgroundColor(Color.YELLOW);
                            }
                            else {
                                itemView.setBackgroundColor(Color.rgb(0,255,0));;
                            }
                            return itemView;
                        }
                    };
                    listView.setAdapter(adapter);

                    // Show resources hidden until data has been loaded
                    searchButton.setVisibility(View.VISIBLE);
                    searchButton.setOnClickListener(new View.OnClickListener()
                    {
                        @Override
                        public void onClick(View v) {
                            initiateSearchPopupWindow(v, alist);
                        }
                    });
                    searchBox1.setVisibility(View.VISIBLE);
                    searchBox1.setHint("Enter date range start!");
                    searchBox2.setVisibility(View.VISIBLE);
                    searchBox2.setHint("Enter date range end!");
                    startButton.setVisibility(View.GONE);
                    heading.setVisibility(View.VISIBLE);

                    // Creation of calendar resources for edit text boxes
                    DatePickerDialog.OnDateSetListener date1 = new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year, int monthOfYear,
                                              int dayOfMonth) {
                            // TODO Auto-generated method stub
                            myCalendar.set(Calendar.YEAR, year);
                            myCalendar.set(Calendar.MONTH, monthOfYear);
                            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                            updateLabel1();
                        }
                    };

                    DatePickerDialog.OnDateSetListener date2 = new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year, int monthOfYear,
                                              int dayOfMonth) {
                            // TODO Auto-generated method stub
                            myCalendar.set(Calendar.YEAR, year);
                            myCalendar.set(Calendar.MONTH, monthOfYear);
                            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                            updateLabel2();
                        }
                    };

                        searchBox1.setOnClickListener(new OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                // TODO Auto-generated method stub
                                new DatePickerDialog(MainActivity.this, date1, myCalendar
                                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
                            }
                    });

                    searchBox2.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            // TODO Auto-generated method stub
                            new DatePickerDialog(MainActivity.this, date2, myCalendar
                                    .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                                    myCalendar.get(Calendar.DAY_OF_MONTH)).show();
                        }
                    });


                    // Handling of linked list item clicks
                    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view,
                                                int position, long id) {

                            // Value of item selected
                            String itemValue = (String) listView.getItemAtPosition(position);

                            // Removal of extra information added for list
                            int index = itemValue.indexOf(" \n\nMagnitude");
                            String itemValueProcessed = itemValue.substring(0, index);

                            // Return full earthquake information based on the selected earthquake
                            for (Earthquake earth : alist) {
                                if (earth.title.equals(itemValueProcessed)) {
                                    initiateDetailsPopupWindow(view, earth);
                                    break;
                                }
                            }
                        }
                    });
                }
            });
        }

        // Pop up window to show details of an earthquake
        @RequiresApi(api = Build.VERSION_CODES.O)
        private void initiateDetailsPopupWindow(View v, Earthquake item) {
            try {
                // Initialization of pop up window
                LayoutInflater inflater = (LayoutInflater) MainActivity.this
                        .getSystemService(MainActivity.LAYOUT_INFLATER_SERVICE);
                View layout = inflater.inflate(R.layout.popup,
                        (ViewGroup) findViewById(R.id.layout2));
                if (layout.getParent() != null) {
                    ((ViewGroup)layout.getParent()).removeView(layout);
                }
                PopupWindow pw = new PopupWindow(MainActivity.this);
                pw.setContentView(layout);
                pw.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
                pw.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
                pw.showAtLocation(v, Gravity.CENTER, 0, 0);
                TextView mResultText = (TextView) layout.findViewById(R.id.popupBox);

                // Cancel button logic
                Button cancelButton = (Button) layout.findViewById(R.id.cancelButton);
                cancelButton.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        pw.dismiss();
                    }
                });

                // All information displayed in the details window
                mResultText.setText("Date: " + item.pubDate
                        + "\n\n Location: " + item.location
                        + "\n\n Magnitude: " + item.magnitude
                        + "\n\n Depth: " + item.depth
                        + "\n\n Category: " + item.category
                        + "\n\n Link: " + item.link
                        + "\n\n Longitude: " + item.geoLong
                        + "\n\n Latitude: " + item.geoLat);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Pop up window to show earthquake information from the chosen range
        @RequiresApi(api = Build.VERSION_CODES.O)
        private void initiateSearchPopupWindow(View v, List<Earthquake> earthquakeList) {
            try {
                // Initialization of pop up window
                LayoutInflater inflater = (LayoutInflater) MainActivity.this
                        .getSystemService(MainActivity.LAYOUT_INFLATER_SERVICE);
                View layout = inflater.inflate(R.layout.popup,
                        (ViewGroup) findViewById(R.id.layout2));
                if (layout.getParent() != null) {
                    ((ViewGroup)layout.getParent()).removeView(layout);
                }
                PopupWindow pw = new PopupWindow(MainActivity.this);
                pw.setContentView(layout);
                pw.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
                pw.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
                pw.showAtLocation(v, Gravity.CENTER, 0, 0);
                TextView mResultText = (TextView) layout.findViewById(R.id.popupBox);

                // Cancel button logic
                Button cancelButton = (Button) layout.findViewById(R.id.cancelButton);
                cancelButton.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        pw.dismiss();
                    }
                });

                // All information displayed in the details window
                float maxMagnitude = 0;
                float maxDepth = 0;
                float minDepth = 0;
                float mostNorthernNum = 0;
                String mostNorthern = "";
                float mostSouthernNum = 0;
                String mostSouthern = "";
                float mostWesternNum = 0;
                String mostWestern = "";
                float mostEasternNum = 0;
                String mostEastern = "";
                Date searchDate1 = new Date();
                Date searchDate2 = new Date();
                DateFormat inputFormat = new SimpleDateFormat("dd MMM yyyy");
                searchDate1 = inputFormat.parse(searchBox1.getText().toString());
                searchDate2 = inputFormat.parse(searchBox2.getText().toString());

                // Logic for discovering information on locations
                for (Earthquake earth : earthquakeList) {

                    // Checking the date range
                    if (earth.pubDate.after(searchDate1) && earth.pubDate.before(searchDate2)) {

                        // Looking for the highest magnitude
                        if (earth.magnitude > maxMagnitude) {
                            maxMagnitude = earth.magnitude;
                        }

                        // Looking for the highest depth
                        if (earth.depth > maxDepth) {
                            maxDepth = earth.depth;
                        }

                        // Looking for the lowest depth
                        if (minDepth == 0) {
                            minDepth = earth.depth;
                        } else {
                            if (earth.depth <= minDepth) {
                                minDepth = earth.depth;
                            }
                        }

                        // Looking for the most northern location
                        if (earth.geoLat > mostNorthernNum) {
                            mostNorthernNum = earth.geoLat;
                            mostNorthern = earth.title;
                        }

                        // Looking for the most southern location
                        if (mostSouthernNum == 0) {
                            mostSouthernNum = earth.geoLat;
                            mostSouthern = earth.title;
                        } else {
                            if (earth.geoLat < mostSouthernNum) {
                                mostSouthernNum = earth.geoLat;
                                mostSouthern = earth.title;
                            }
                        }

                        // Looking for the most eastern location
                        if (mostEasternNum == 0) {
                            mostEasternNum = earth.geoLong;
                            mostEastern = earth.title;
                        } else {
                            if (earth.geoLong > mostEasternNum) {
                                mostEasternNum = earth.geoLong;
                                mostEastern = earth.title;
                            }
                        }

                        // Looking for the most western location
                        if (mostWesternNum == 0) {
                            mostWesternNum = earth.geoLong;
                            mostWestern = earth.title;
                        } else {
                            if (earth.geoLong < mostWesternNum) {
                                mostWesternNum = earth.geoLong;
                                mostWestern = earth.title;
                            }
                        }
                    }
                }

                // Displaying the output
                mResultText.setText("Highest Magnitude: " + maxMagnitude + "\n\nHighest Depth: " + maxDepth + "\n\nLowest Depth: " + minDepth +
                        "\n\nMost Northern: " + mostNorthern + "\nMagnitude: " + mostNorthernNum +
                        "\n\nMost Southern: " + mostSouthern + "\nMagnitude: " + mostSouthernNum +
                        "\n\nMost Eastern: " + mostEastern + "\nMagnitude: " + mostEasternNum +
                        "\n\nMost Western: " + mostWestern + "\nMagnitude: " + mostWesternNum);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}